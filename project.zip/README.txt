The main method is preset to creating a union DFA using the dfaA.txt
and dfaB.txt files. Also included in the project.zip are dfaC.txt and dfaD.txt.

To test the DFA Union Builder:
1. Set the fileNames to any combination of the dfa .txt files
2. The program will generate a dfaUnion.txt file which contains
the formal description of the union DFA with proper formatting
delimited with commas and semicolons.
